from django.shortcuts import render
from django.conf import settings
from django.http import JsonResponse
import razorpay



def home(request):
  
    return render(request, 'home.html'),

